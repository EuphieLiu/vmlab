#!/bin/bash
# Usage -- ./demo.sh x y, where x is the start index and y is the last index of the rows in the data set.

python3 ./worker.py ${1} ${2}